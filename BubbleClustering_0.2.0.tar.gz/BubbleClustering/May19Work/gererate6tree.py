import random
import math
import numpy


count=0
for test in range(1000000):
        coords=list()
        for i in range(12):
                coords.append(random.uniform(-100,100))

        matrix= [ 
                [coords[0], coords[1]],
                [coords[2], coords[3]],
                [coords[4], coords[5]],
                [coords[6], coords[7]],
                [coords[8], coords[9]],
                [coords[10], coords[11]]
                ]
                
        distances=list()
        for i in range(6):
                for j in range(6-i-1):
                        distances.append(math.sqrt( ((matrix[i][0]-matrix[j+i+1][0])**2)+((matrix[i][1]-matrix[j+i+1][1])**2) ))
                        
        ranking = sorted(distances)
        index = [ranking.index(v) for v in distances]
        
        if (index.index(0)== 0) or (index.index(0)== 12):
                if (index.index(1)== 0) or (index.index(1)== 12):
                        if (index.index(2)==1)or (index.index(2)==5):
                                if (index.index(3)==2) or (index.index(3)==3) or (index.index(3)==6) or (index.index(3)==7) or (index.index(3)==9) or (index.index(3)==10):
                                        if (index.index(4)==4) or (index.index(4)==8) or (index.index(4)==11) or (index.index(4)==13) or (index.index(4)==14):
                                                count+=1
                                                name=("Dataset"+str(count)+".csv")
                                                numpy.savetxt(name, matrix, delimiter=",")
                                                        
        if (test%100000==0):
                print("count so far:",count)

print("total:",count)

